# Cercospora_brinjal > 2024-11-17 5:58pm
https://universe.roboflow.com/deepan-siva/cercospora_brinjal

Provided by a Roboflow user
License: CC BY 4.0

